import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';

enum TimerMode { focus, shortBreak, longBreak }

class TimerPage extends ConsumerStatefulWidget {
  const TimerPage({super.key});

  @override
  ConsumerState<TimerPage> createState() => _TimerPageState();
}

class _TimerPageState extends ConsumerState<TimerPage> {
  TimerMode _mode = TimerMode.focus;
  Timer? _timer;
  int _seconds = 25 * 60;
  bool _isRunning = false;
  int _sessionCount = 0;

  final Map<TimerMode, int> _durations = {
    TimerMode.focus: 25 * 60,
    TimerMode.shortBreak: 5 * 60,
    TimerMode.longBreak: 15 * 60,
  };

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _setMode(TimerMode mode) {
    _timer?.cancel();
    setState(() {
      _mode = mode;
      _seconds = _durations[mode]!;
      _isRunning = false;
    });
  }

  void _toggle() {
    if (_isRunning) {
      _timer?.cancel();
      setState(() => _isRunning = false);
    } else {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (_seconds > 0) {
          setState(() => _seconds--);
        } else {
          _timer?.cancel();
          setState(() {
            _isRunning = false;
            if (_mode == TimerMode.focus) _sessionCount++;
          });
        }
      });
      setState(() => _isRunning = true);
    }
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _seconds = _durations[_mode]!;
      _isRunning = false;
    });
  }

  String get _timeString {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  double get _progress {
    final total = _durations[_mode]!;
    return 1 - (_seconds / total);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Timer'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Chip(
              label: Text('$_sessionCount sessions'),
              backgroundColor: AppColors.primary.withOpacity(0.1),
              labelStyle: const TextStyle(color: AppColors.primary),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Mode selector
            Container(
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceVariant.withOpacity(0.3),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  _ModeTab(
                      label: 'Focus',
                      selected: _mode == TimerMode.focus,
                      onTap: () => _setMode(TimerMode.focus)),
                  _ModeTab(
                      label: 'Short Break',
                      selected: _mode == TimerMode.shortBreak,
                      onTap: () => _setMode(TimerMode.shortBreak)),
                  _ModeTab(
                      label: 'Long Break',
                      selected: _mode == TimerMode.longBreak,
                      onTap: () => _setMode(TimerMode.longBreak)),
                ],
              ),
            ),
            const Spacer(),

            // Timer circle
            SizedBox(
              width: 260,
              height: 260,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 260,
                    height: 260,
                    child: CircularProgressIndicator(
                      value: _progress,
                      strokeWidth: 10,
                      backgroundColor: AppColors.primary.withOpacity(0.1),
                      valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _timeString,
                        style: theme.textTheme.displayMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          letterSpacing: 4,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _mode == TimerMode.focus
                            ? AppStrings.focusTime
                            : _mode == TimerMode.shortBreak
                                ? AppStrings.shortBreak
                                : AppStrings.longBreak,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Spacer(),

            // Controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.outlined(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh),
                  iconSize: 28,
                ),
                const SizedBox(width: 20),
                SizedBox(
                  width: 120,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _toggle,
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          _isRunning ? AppColors.error : AppColors.primary,
                    ),
                    child: Text(_isRunning ? 'Pause' : 'Start'),
                  ),
                ),
                const SizedBox(width: 20),
                IconButton.outlined(
                  onPressed: () {},
                  icon: const Icon(Icons.skip_next_outlined),
                  iconSize: 28,
                ),
              ],
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _ModeTab extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ModeTab(
      {required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? AppColors.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? Colors.white : AppColors.textMuted,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}
