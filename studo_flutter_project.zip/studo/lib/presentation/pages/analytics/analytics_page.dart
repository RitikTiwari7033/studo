import 'package:flutter/material.dart';

class AnalyticsPage extends StatelessWidget {
  const AnalyticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('AnalyticsPage')),
      body: const Center(child: Text('AnalyticsPage — coming soon')),
    );
  }
}
