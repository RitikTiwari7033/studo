import 'package:flutter/material.dart';

class NoteDetailPage extends StatelessWidget {
  final String noteId;
  const NoteDetailPage({super.key, required this.noteId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Note Detail')),
      body: Center(child: Text('Note ID: $noteId')),
    );
  }
}
