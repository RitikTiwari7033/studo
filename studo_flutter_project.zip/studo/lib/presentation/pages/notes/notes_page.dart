import 'package:flutter/material.dart';

class NotesPage extends StatelessWidget {
  const NotesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('NotesPage')),
      body: const Center(child: Text('NotesPage — coming soon')),
    );
  }
}
