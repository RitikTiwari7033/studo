import 'package:flutter/material.dart';

class TasksPage extends StatelessWidget {
  const TasksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('TasksPage')),
      body: const Center(child: Text('TasksPage — coming soon')),
    );
  }
}
