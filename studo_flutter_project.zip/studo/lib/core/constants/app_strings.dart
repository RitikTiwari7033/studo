class AppStrings {
  AppStrings._();

  // App
  static const String appName = 'Studo';
  static const String appTagline = 'Study smarter, not harder';

  // Auth
  static const String signIn = 'Sign In';
  static const String signUp = 'Sign Up';
  static const String signOut = 'Sign Out';
  static const String email = 'Email';
  static const String password = 'Password';
  static const String forgotPassword = 'Forgot Password?';
  static const String continueWithGoogle = 'Continue with Google';
  static const String noAccount = "Don't have an account? ";
  static const String hasAccount = 'Already have an account? ';

  // Home
  static const String goodMorning = 'Good Morning';
  static const String goodAfternoon = 'Good Afternoon';
  static const String goodEvening = 'Good Evening';
  static const String todayGoal = "Today's Goal";
  static const String recentNotes = 'Recent Notes';
  static const String upcomingTasks = 'Upcoming Tasks';

  // Navigation
  static const String home = 'Home';
  static const String notes = 'Notes';
  static const String timer = 'Timer';
  static const String tasks = 'Tasks';
  static const String analytics = 'Analytics';

  // Timer
  static const String focusTime = 'Focus Time';
  static const String shortBreak = 'Short Break';
  static const String longBreak = 'Long Break';
  static const String startSession = 'Start Session';
  static const String pauseSession = 'Pause';
  static const String resetSession = 'Reset';

  // Notes
  static const String newNote = 'New Note';
  static const String noNotes = 'No notes yet';
  static const String searchNotes = 'Search notes...';

  // Tasks
  static const String newTask = 'New Task';
  static const String noTasks = 'No tasks yet';
  static const String completed = 'Completed';
  static const String pending = 'Pending';

  // Errors
  static const String somethingWentWrong = 'Something went wrong';
  static const String noInternet = 'No internet connection';
  static const String tryAgain = 'Try Again';
}
