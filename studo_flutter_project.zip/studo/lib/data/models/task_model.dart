import 'package:cloud_firestore/cloud_firestore.dart';

enum TaskPriority { low, medium, high }

class TaskModel {
  final String id;
  final String title;
  final String? description;
  final String subject;
  final DateTime? dueDate;
  final bool isCompleted;
  final TaskPriority priority;
  final String userId;

  const TaskModel({
    required this.id,
    required this.title,
    this.description,
    required this.subject,
    this.dueDate,
    required this.isCompleted,
    required this.priority,
    required this.userId,
  });

  factory TaskModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TaskModel(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'],
      subject: data['subject'] ?? '',
      dueDate: data['dueDate'] != null
          ? (data['dueDate'] as Timestamp).toDate()
          : null,
      isCompleted: data['isCompleted'] ?? false,
      priority: TaskPriority.values[data['priority'] ?? 1],
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'subject': subject,
    'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
    'isCompleted': isCompleted,
    'priority': priority.index,
    'userId': userId,
  };
}
